import './ErrorPage.css'

const ErrorPage = () => {
    return (
        <div className='errorPage'>
            <h1>EH! VOLEVI!</h1>  
            <iframe width="445" height="791" src="https://www.youtube.com/embed/pSq2Jgl430s?autoplay=1" title="Eh!Volevi!" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

        </div>
        
    )
}

export default ErrorPage