# Getting Started

This project has only two installations required:
1. npm i
2. npm @reduxjs/toolkit react-redux react-router-dom

NO CSS FRAMEWORK WAS USED!

## The Team:

1. Francesco Cannizzo
2. Francesco Margotta
3. Daniel Santini
4. Lorenzo Zuccante
5. Andrea Battaglia
6. Massimo Spinosa

Everyone contributed on the project with creating the components and building the logical structure together

## What is the project

The project was born as a LinkedIn clone desktop web app, but then we decided to also make it fully responsive.

## IMPORTANT!!!

Open opera browser and type any word on the url after the normal one

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.